
from setuptools import setup

setup(
    name='package',
    version='0.1.0',
    description= 'First Package',
    packages=['package'],
)